const rooms=[
 {id:"101",capacity:30,equipment:"Проектор, Wi‑Fi, тақта"},
 {id:"203",capacity:20,equipment:"Проектор, компьютер, Wi‑Fi"},
 {id:"305",capacity:40,equipment:"Интерактивті тақта, Wi‑Fi"},
 {id:"401",capacity:15,equipment:"Компьютерлер, Wi‑Fi"}
];

let bookings=JSON.parse(localStorage.getItem("roomBookings")||"[]");

const roomList=document.getElementById("roomList");
const roomSelect=document.getElementById("room");
const bookingList=document.getElementById("bookingList");
const form=document.getElementById("bookingForm");
const message=document.getElementById("message");

function renderRooms(){
 roomList.innerHTML="";
 roomSelect.innerHTML="";
 rooms.forEach(r=>{
   roomList.innerHTML+=`<div class="card"><h3>№ ${r.id}</h3><p><b>Сыйымдылығы:</b> ${r.capacity} адам</p><p><b>Құралдар:</b> ${r.equipment}</p><span class="badge">Қолжетімді</span></div>`;
   roomSelect.innerHTML+=`<option value="${r.id}">№ ${r.id}</option>`;
 });
}
function save(){localStorage.setItem("roomBookings",JSON.stringify(bookings));}
function renderBookings(){
 if(!bookings.length){bookingList.innerHTML="<p>Әзірге бронь жасалмаған.</p>";return;}
 bookingList.innerHTML=bookings.map((b,i)=>`
 <div class="booking">
   <div><b>Аудитория №${b.room}</b><br>${b.name} — ${b.date}, ${b.start}–${b.end}<br><small>${b.purpose}</small></div>
   <button class="btn danger" onclick="removeBooking(${i})">Жою</button>
 </div>`).join("");
}
function removeBooking(i){bookings.splice(i,1);save();renderBookings();}
form.addEventListener("submit",e=>{
 e.preventDefault();
 const b={room:roomSelect.value,name:name.value.trim(),date:date.value,start:start.value,end:end.value,purpose:purpose.value.trim()};
 if(b.start>=b.end){message.className="error";message.textContent="Аяқталу уақыты басталу уақытынан кейін болуы керек.";return;}
 const conflict=bookings.some(x=>x.room===b.room&&x.date===b.date&&b.start<x.end&&b.end>x.start);
 if(conflict){message.className="error";message.textContent="Бұл аудитория көрсетілген уақытта бос емес.";return;}
 bookings.push(b);save();renderBookings();form.reset();
 message.className="success";message.textContent="Бронь сәтті жасалды!";
});
renderRooms();renderBookings();
const today=new Date().toISOString().split("T")[0]; document.getElementById("date").min=today;
